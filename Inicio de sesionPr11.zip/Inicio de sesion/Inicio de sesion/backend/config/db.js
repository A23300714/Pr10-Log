// Importa la librería para MySQL
const mysql = require('mysql2');
// Importa dotenv para leer las variables de entorno
require('dotenv').config();
// Crea la conexión con la base de datos usando variables de entorno
const connection = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
});
// Intenta conectarse
connection.connect((error) => {
  if (error) {
    console.log("Error de conexión");
    return;
  }
  console.log("Conectado a MySQL");
});
// Exporta la conexión
module.exports = connection;