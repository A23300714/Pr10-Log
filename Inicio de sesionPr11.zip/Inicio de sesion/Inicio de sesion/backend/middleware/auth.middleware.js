// Importamos jsonwebtoken para verificar tokens
const jwt = require('jsonwebtoken');
// Middleware de autenticación
const verifyToken = (req, res, next) => {
    // Obtenemos el header Authorization
    const authHeader = req.headers['authorization'];
    // Si no existe el header, no hay token
    if (!authHeader) {
        return res.status(403).json({
            message: 'Token requerido'
        });
    }
    // El token viene así: Bearer TOKEN
    const token = authHeader.split(' ')[1];
    // Si no hay token después de Bearer
    if (!token) {
        return res.status(403).json({
            message: 'Token inválido'
        });
    }
    // Verificamos el token
    jwt.verify(token, process.env.JWT_SECRET, (error, decoded) => {
        // Si el token está vencido o es incorrecto
        if (error) {
            return res.status(401).json({
                message: 'Token no autorizado'
            });
        }
        // Guardamos los datos del usuario en la petición
        req.user = decoded;
        // Permitimos continuar hacia el controlador
        next();
    });
};
// Exportamos el middleware
module.exports = verifyToken;

