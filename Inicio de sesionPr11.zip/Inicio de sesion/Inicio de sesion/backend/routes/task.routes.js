// Importa Express
const express = require('express');
// Crea el enrutador
const router = express.Router();
// Importa el controlador de tareas
const taskController = require('../controllers/task.controller');
// Ruta para obtener tareas de un usuario específico
router.get('/:id_usuario', taskController.getTasks);
// Ruta para crear una nueva tarea
router.post('/', taskController.createTask);
// Exporta el router
module.exports = router;