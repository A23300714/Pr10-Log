// Importa Express
const express = require('express');
// Crea el enrutador
const router = express.Router();
// Importa el controlador
const authController = require('../controllers/auth.controller');
// Ruta para registrar usuarios
router.post(
  '/register',
  authController.register
);
// Ruta para iniciar sesión
router.post(
  '/login',
  authController.login
);
// Exporta el router
module.exports = router;