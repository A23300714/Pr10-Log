// Importa Express
const express = require('express');
// Importa CORS
const cors = require('cors');
// Importa dotenv para las variables de entorno
require('dotenv').config();
// Crea la aplicación
const app = express();
// Permite recibir JSON
app.use(express.json());
// Permite peticiones desde el navegador
app.use(cors());
// Importa las rutas de autenticación
const authRoutes = require('./routes/auth.routes');
// Importa las rutas de tareas
const taskRoutes = require('./routes/task.routes');
// Asocia las rutas
app.use('/api/auth', authRoutes);
app.use('/api/tasks', taskRoutes);
// Inicia el servidor usando el puerto de las variables de entorno o el 3000 por defecto
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor iniciado en el puerto ${PORT}`);
});