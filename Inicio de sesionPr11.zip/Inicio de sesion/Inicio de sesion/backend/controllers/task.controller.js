// Importa la conexión a la base de datos
const db = require('../config/db');

// Obtiene todas las tareas de un usuario
exports.getTasks = (req, res) => {
  const { id_usuario } = req.params;

  const sql = 'SELECT * FROM tareas WHERE id_usuario = ?';
  db.query(sql, [id_usuario], (error, results) => {
    if (error) {
      return res.status(500).json({ message: 'Error al obtener las tareas' });
    }
    res.status(200).json(results);
  });
};

// Crea una nueva tarea asociada a un usuario
exports.createTask = (req, res) => {
  const { titulo, id_usuario } = req.body;

  if (!titulo || !id_usuario) {
    return res.status(400).json({ message: 'Campos incompletos' });
  }

  const sql = 'INSERT INTO tareas (titulo, id_usuario) VALUES (?, ?)';
  db.query(sql, [titulo, id_usuario], (error, result) => {
    if (error) {
      return res.status(500).json({ message: 'Error al crear la tarea' });
    }
    res.status(201).json({ message: 'Tarea creada con éxito' });
  });
};