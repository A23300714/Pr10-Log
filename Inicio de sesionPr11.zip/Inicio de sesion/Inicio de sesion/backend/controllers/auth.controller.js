// Importa la conexión a la base de datos
const db = require('../config/db');

// Importa bcrypt
const bcrypt = require('bcrypt');

exports.register = async (req, res) => {

  // Obtiene los datos enviados desde el formulario (correo)
  const { correo, password } = req.body;

  // Validación de campos vacíos
  if (!correo || !password) {
    return res.status(400).json({
      message: 'Debe capturar correo y contraseña'
    });
  }

  // Verifica si el usuario ya existe por su correo
  const sqlSearch = 'SELECT * FROM usuarios WHERE correo = ?';

  db.query(
    sqlSearch,
    [correo],
    async (error, results) => {

      if (error) {
        return res.status(500).json({
          message: 'Error del servidor'
        });
      }

      if (results.length > 0) {
        return res.status(409).json({
          message: 'El usuario ya existe'
        });
      }

      // Genera el hash de la contraseña
      const hashedPassword = await bcrypt.hash(password, 10);

      // Inserta el nuevo usuario con la contraseña hasheada
      const sqlInsert = 'INSERT INTO usuarios(correo, contraseña) VALUES(?,?)';

      db.query(
        sqlInsert,
        [correo, hashedPassword],
        (error, result) => {

          if (error) {
            return res.status(500).json({
              message: 'No se pudo registrar el usuario'
            
            });
          }
          res.status(201).json({
            message: 'Usuario registrado correctamente'
          });

        }
      );
    }
  );
};


exports.login = (req, res) => {

  const { correo, password } = req.body;

  // Validación de campos vacíos
  if (!correo || !password) {
    return res.status(400).json({
      message: 'Debe capturar correo y contraseña'
    });
  }

  // Busca el usuario por correo
  const sql = 'SELECT * FROM usuarios WHERE correo = ?';

  db.query(
    sql,
    [correo],
    async (error, results) => {

      if (error) {
        return res.status(500).json({
          message: 'Error del servidor'
        });
      }

      if (results.length === 0) {
        return res.status(404).json({
          message: 'El usuario no existe'
        });
      }

      const user = results[0];

      // Compara la contraseña capturada con el hash almacenado
      const coincide = await bcrypt.compare(
        password,
        user.contraseña
      );

      if (!coincide) {
        return res.status(401).json({
          message: 'Contraseña incorrecta'
        });
      }

      // Login exitoso devolviendo el ID del usuario para gestionar sus tareas
      res.status(200).json({
        message: `Bienvenido ${user.correo}`,
        userId: user.id
      });

    }
  );
};