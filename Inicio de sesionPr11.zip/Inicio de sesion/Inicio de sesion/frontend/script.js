// URL base del backend
const API_URL = "http://localhost:3000/api";
// Variables globales para mantener el estado del usuario activo
let currentUserId = null;
async function register() {
  // Obtiene los datos enviados desde el formulario
  const correo = document.getElementById("registerCorreo").value;
  const password = document.getElementById("registerPassword").value;
  const response = await fetch(
    `${API_URL}/auth/register`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        correo: correo,
        password: password
      })
    }
  );
  const data = await response.json();
  alert(data.message);
}

async function login() {
  const correo = document.getElementById("loginCorreo").value;
  const password = document.getElementById("loginPassword").value;
  const response = await fetch(
    `${API_URL}/auth/login`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        correo: correo,
        password: password
      })
    }
  );
  const data = await response.json();
  alert(data.message);
  // Si el login es exitoso, guarda el ID y muestra dashboard de tareas
  if (response.status === 200) {
    currentUserId = data.userId;
    document.getElementById("welcomeMessage").innerText = data.message;
    document.getElementById("authSection").classList.add("hidden");
    document.getElementById("dashboardSection").classList.remove("hidden");
    loadTasks();
  }
}
// Carga las tareas guardadas del usuario actual
async function loadTasks() {
  const response = await fetch(`${API_URL}/tasks/${currentUserId}`);
  const tasks = await response.json();
  const taskList = document.getElementById("taskList");
  taskList.innerHTML = ""; // Limpia la lista anterior
  tasks.forEach(task => {
    const li = document.createElement("li");
    li.innerText = task.titulo;
    taskList.appendChild(li);
  });
}
// Envía una nueva tarea al backend
async function createTask() {
  const titulo = document.getElementById("taskTitle").value;
  if (!titulo) return alert("Escribe un título para la tarea");
  const response = await fetch(
    `${API_URL}/tasks`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        titulo: titulo,
        id_usuario: currentUserId
      })
    }
  );
  const data = await response.json();
  document.getElementById("taskTitle").value = ""; // Limpia el input
  loadTasks(); // Recarga la lista visible
}
// Regresa al estado inicial de autenticación
function logout() {
  currentUserId = null;
  document.getElementById("authSection").classList.remove("hidden");
  document.getElementById("dashboardSection").classList.add("hidden");
}